# mmicracky

## Umgebung

    MMI-Pharmindex
    ├── mmicracky
    │   ├── mmicracky.py
    │   ├── MMI_PHARMINDEX.csv <-- Ausgabedatei; wird generiert.
    │   ├── RENAME_COLUMNS.CSV <-- Versionierte Datei die beschreibt, wie die
    │   │                          Spalten bei der Erzeugung der Ausgabedateien
    │   │                          umbenannt werden.
    │   └── README.md
    ├── MMI_RohdatenR3
    ├── ...
    ├── MMI_RohdatenR3_Fachinformation
    ├── ...
    ├── MMI_RohdatenR3_Test
    └── ...

## Ausführung

    python mmicracky.py
