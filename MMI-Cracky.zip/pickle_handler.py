# -*- coding: utf-8 -*-
import pandas as pd
import os

pkl_path = './data/'


def to_path(csv_file):
    csv_str = csv_file.split('/')[-1]
    return f'{pkl_path}{csv_str}.pkl'


def load(csv_file):
    try:
        df = pd.read_pickle(to_path(csv_file))
    except FileNotFoundError:
        df = save(csv_file)
    return df


def save(csv_file):
    df = pd.read_csv(csv_file, sep=';')
    try:
        os.mkdir(pkl_path)
    except FileExistsError:
        pass
    df.to_pickle(to_path(csv_file))
    return df

# Usage (only use load() )
# csv_file = '../MMI_RohdatenR3/mmiPharmindexR3_20211101MAIN/ITEM.CSV'
# df = load(csv_file)
# print(df)