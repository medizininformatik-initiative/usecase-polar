# -*- coding: utf-8 -*-
import glob2
import sys
import pandas as pd
from functools import reduce
import warnings
import time
import pickle_handler
warnings.filterwarnings("ignore")
t = time.time()
###############################################################################
# INITIALIZE
###############################################################################
# Detect the date in the filenames to automatically read the .csv-files
# depending on these dates making the code more resilient for updates of the
# MMI-Pharmindex.
path = '../MMI_RohdatenR3/mmiPharmindexR3_'
fils = [fil for fil in glob2.glob('../**/*.CSV') if path in fil]
date = fils[0].split(path)[1].split('/')[0]
csvs = ['ITEM_ATC.CSV', 'ITEM.CSV', 'PRODUCT.CSV', 'PRODUCT_COMPANY.CSV',
        'COMPANY.CSV', 'PACKAGE.CSV', 'CLINICALPACKAGE.CSV', 'PRODUCT_ICD.CSV',
        'MOLECULE.CSV', 'COMPOSITIONELEMENT.CSV',
        'ITEM_COMPOSITIONELEMENT.CSV']
MMI_ITEM_ATC, MMI_ITEM, MMI_PRODUCT, MMI_PRODUCT_COMPANY, MMI_COMPANY, \
    MMI_PACKAGE, MMI_CLINICALPACKAGE, MMI_PRODUCT_ICD, MMI_MOLECULE, \
    MMI_COMPOSITIONELEMENT, MMI_ITEM_COMPOSITIONELEMENT = \
    [pickle_handler.load(f"{path}{date}/{csv}") for csv in csvs]
# This dictionary defines the order in which the dataframes are merged. The
# keys of the dictionary represent the code which is provided by merging. The
# first element of the dict-values contains the origin of the merge, i.e. the
# dataframe containing the code which is already provided. The last element of
# the dict-values contains the destination dataframe, i.e. the dataframe
# containing the code which will be provided after the merge. Each item in a
# list of dict-values contains a dataframe (i.e. the content of one .csv-table)
# and the columns within this table that are used to perform the merge. The
# last column in this list corresponds to the first column in the next items
# list, thereby creating a link between the dataframes which is used to merge
# the dataframes recursively.
mappings = {
            "ATCCODE": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_ITEM, ['PRODUCTID', 'ID']),
                    (MMI_ITEM_ATC, ['ITEMID', 'ATCCODE']),
                ],
            "ICDCODE": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_PRODUCT_ICD, ['PRODUCTID', 'ICDCODE']),
                ],
            "CASREGISTRATIONNUMBER": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_ITEM, ['PRODUCTID', 'ID']),
                    (MMI_ITEM_COMPOSITIONELEMENT, ['ITEMID', 'COMPOSITIONELEMENTID']),
                    (MMI_COMPOSITIONELEMENT, ['ID', 'MOLECULEID']),
                    (MMI_MOLECULE, ['ID', 'CASREGISTRATIONNUMBER']),
                ],
            "ASKNUMBER": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_ITEM, ['PRODUCTID', 'ID']),
                    (MMI_ITEM_COMPOSITIONELEMENT, ['ITEMID', 'COMPOSITIONELEMENTID']),
                    (MMI_COMPOSITIONELEMENT, ['ID', 'MOLECULEID']),
                    (MMI_MOLECULE, ['ID', 'ASKNUMBER']),
                ],
            "IFAPHARMFORMCODE": [
                    (MMI_PACKAGE, ['PZN', 'IFAPHARMFORMCODE'])
                ],
            "COMPANY_NAME": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_PRODUCT_COMPANY, ['PRODUCTID', 'COMPANYID']),
                    (MMI_COMPANY, ['ID', 'NAME']),
                ],
            "STRENGTH_DENOMINATOR_VALUE": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_ITEM, ['PRODUCTID', 'BASECOUNT']),
                ],
            "STRENGTH_DENOMINATOR_UNIT": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_ITEM, ['PRODUCTID', 'BASEMOLECULEUNITCODE']),
                ],
            "STRENGTH_NUMERATOR_VALUE": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_ITEM, ['PRODUCTID', 'ID']),
                    (MMI_ITEM_COMPOSITIONELEMENT, ['ITEMID', 'COMPOSITIONELEMENTID']),
                    (MMI_COMPOSITIONELEMENT, ['ID', 'MASSFROM']),
                ],
            "STRENGTH_NUMERATOR_UNIT": [
                    (MMI_PACKAGE, ['PZN', 'PRODUCTID']),
                    (MMI_ITEM, ['PRODUCTID', 'ID']),
                    (MMI_ITEM_COMPOSITIONELEMENT, ['ITEMID', 'COMPOSITIONELEMENTID']),
                    (MMI_COMPOSITIONELEMENT, ['ID', 'MOLECULEUNITCODE']),
                ],
    }
###############################################################################
# FUNCTIONS
###############################################################################
def unique(lis):
    """Helper function to unify a list of elements in order."""
    return [x for i, x in enumerate(lis) if lis.index(x) == i]


def filter_df(df):
    """
    Filtering logic documented using doctest. Removes nan values and
    duplicates.

    :param df: pandas.core.frame.DataFrame
    :return: pandas.core.frame.DataFrame

    >>> data = {
    ... 'NAME_PLAIN': ["Pheniramin", "Molnupiravir", "Cymbopogon nardus", "Pentoxifyllin"],
    ... 'ASKNUMBER':  [        2899,          pd.NA,               pd.NA,            6103]}
    >>> df = pd.DataFrame(data=data)
    >>> filter_df(df)
          NAME_PLAIN ASKNUMBER
    0     Pheniramin      2899
    1  Pentoxifyllin      6103
    >>> data = {
    ... 'PZN':     [17842418, 17838374,  17551537,  17551537],
    ... 'ATCCODE': [ "V07AG",  "V07AG", "B02BD02", "B02BD02"]}
    >>> df = pd.DataFrame(data=data)
    >>> filter_df(df)
            PZN  ATCCODE
    0  17842418    V07AG
    1  17838374    V07AG
    2  17551537  B02BD02
    >>> # Only keep the first ATC-Code for duplicate ATCs corresponding to PZNs.
    >>> data = {
    ... 'PZN':     [  1394455,  13821282,  13821282,  13821276,  13821276,   3098123],
    ... 'ATCCODE': ["C04AD03", "N03AX11", "N02CX12", "N03AX11", "N02CX12", "S01ED02"]}
    >>> df = pd.DataFrame(data=data)
    >>> filter_df(df)
            PZN  ATCCODE
    0   1394455  C04AD03
    1  13821282  N03AX11
    2  13821276  N03AX11
    3   3098123  S01ED02
    >>> data = {
    ... 'NAME_PLAIN': ["Aluminium", "Aluminum", "Palmitinsäure", "Palmitic Acid"],
    ... 'ASKNUMBER':  [       1854,       1854,            5038,            5038]}
    >>> df = pd.DataFrame(data=data)
    >>> filter_df(df)
          NAME_PLAIN  ASKNUMBER
    0      Aluminium       1854
    1  Palmitinsäure       5038
    >>> # ASK-Codes are mapped to a list of ASK-Codes for each PZN.
    >>> data = {
    ... 'PZN':       [998240, 998240, 998240, 998240, 998257, 998257, 998257, 998257, 998375],
    ... 'ASKNUMBER': [  2015,  pd.NA,   5237, pd.NaT,   8440,  pd.NA, pd.NaT,   2124,   1333]}
    >>> df = pd.DataFrame(data=data)
    >>> filter_df(df)
          PZN  ASKNUMBER
    0  998240  2015,5237
    1  998257  8440,2124
    2  998375       1333
    >>> data = {
    ... 'PZN':     [1394455, 1394455, 17638379, 17638379],
    ... 'ICDCODE': [ "I.22", "I73.9",    "G.1",    "G.3"]}
    >>> df = pd.DataFrame(data=data)
    >>> filter_df(df)
            PZN     ICDCODE
    0   1394455  I.22,I73.9
    1  17638379     G.1,G.3
    """
    # Remove nan values and duplicates.
    df = df.dropna().drop_duplicates()
    # Unify primary key.
    primary_keys = ["PZN"]  # The primary keys of the tables.
    # The keys that are listed with respect to the PZN.
    aslist = {('PZN', 'ASKNUMBER'): True,
              ('PZN', 'ICDCODE'): True,
              ('PZN', 'NAME'): True}
    cols = df.columns.values
    # Get the primary key and columns that are converted to lists.
    intersect = list(set(cols).intersection(set(primary_keys)))
    pk = intersect[0] if len(intersect) > 0 else \
            'PZN' if 'PZN' in cols else 'ASKNUMBER'
    listk = list(set(cols) - {pk})[0]
    # Remove duplicates.
    mask = []
    keys = {}
    if aslist.get(tuple(cols), False):  # Mapping for PZN- and listed Codes for which duplicates are kept.
        listed = {}
    for idx, line in enumerate(df.values):
        # Get value of column c in line
        val = lambda c: line[list(cols).index(c)]
        if val(pk) in keys:
            mask += [False]
        else:
            mask += [True]
            keys[val(pk)] = None
        # Mapping for PZN- and listed Codes for which duplicates are kept.
        if aslist.get(tuple(cols), False):
            if val("PZN") not in listed:
                listed[val("PZN")] = [val(listk)]
            else:
                listed[val("PZN")] += [val(listk)]
    df = df.iloc[mask]
    # Mapping for PZN- and listed Codes for which duplicates are kept.
    if aslist.get(tuple(cols), False):
        listed = [(a, ','.join([str(_) for _ in listed[a]])) for a in listed]
        df = pd.DataFrame(listed, columns=cols)
    return df.reset_index(drop=True)


def merge_dfs(merge):
    """This function performs a recursive merge over a list of dataframes. The
    function performs one merge of two dataframes at a time and discards the
    ID upon which the join operation was performed. The join operation thereby
    traversed over the list of dataframes until the head of the recursive call
    reaches the final destination of the join represented by the last
    (sub-)entry in merge."""
    if len(merge) == 1:
        keep_cols = [merge[0][1][0], merge[0][1][1]]
        df = merge[0][0]
    else:
        f, s = merge[0], merge[1]  # First and second element: The recursion head.
        f = (f[0].filter(unique(f[1])), f[1])
        s = (s[0].filter(unique(s[1])), s[1])
        # Join on these columns
        lo, ro = f[1][1], s[1][0]
        # Merge the recursion head.
        df = pd.merge(f[0], s[0], how='inner', left_on=[lo], right_on=[ro])
        # Only keep the columns which have not been joined.
        keep_cols = [_ for _ in df.columns.values if _ not in [lo, ro]]
    df = df.filter(keep_cols)
    # Join result with the recursion tail or return if last join was performed.
    if len(merge) > 2:
        return merge_dfs([(df, keep_cols)] + merge[2:])
    else:
        return df


def create_df(mapping_string):
    """Fetches the correct mapping, merges the corresponding dataframes and
    filters the result.

    :param mapping_string: key for the mapping dictionary
    :return: pandas.core.frame.DataFrame
    """
    return filter_df(merge_dfs(mappings[mapping_string]))


###############################################################################
# CONVERT THE MMI PHARMINDEX
###############################################################################
# Assemble dataframes for specific columns depending on the PZN.
df_strings = ["ATCCODE", "ASKNUMBER", "ICDCODE", "IFAPHARMFORMCODE",
              "COMPANY_NAME", "CASREGISTRATIONNUMBER",
              "STRENGTH_NUMERATOR_VALUE", "STRENGTH_NUMERATOR_UNIT",
              "STRENGTH_DENOMINATOR_VALUE", "STRENGTH_DENOMINATOR_UNIT",
              ]
# To rename columns in the output files.
rename = pd.read_csv('RENAME_COLUMNS.CSV', sep=',', header=None)
rename = {old: new for (old, new) in rename.values}
# Assemble main output table.
try:
    mmi_pharmindex = pickle_handler.load("MMI_PHARMINDEX.csv")
except:
    mmi_pharmindex = reduce(lambda l, r: pd.merge(l, r, on=['PZN'], how='outer'),
                       [create_df(ds) for ds in df_strings])
    mmi_pharmindex['PZN'] = mmi_pharmindex['PZN'].astype('Int64')
    mmi_pharmindex.rename(columns=rename, inplace=True)
    mmi_pharmindex.to_csv("MMI_PHARMINDEX.csv", index=None, sep=';')
# Assertions
assert len(list(mmi_pharmindex["PZN"])) == len(set(list(mmi_pharmindex["PZN"]))), \
    "Die PZN ist in der 1. Spalte unique und wird einem ATC-Code zugeordnet."
assert not mmi_pharmindex.duplicated().sum() > 0, \
    "Die Ausgabe enthält keine Duplikate"

if __name__ == "__main__":
    import doctest
    doctest.testmod()
elapsed = time.time() - t
limit = 30
if elapsed > limit:
    print(f"Laufzeit: {elapsed}")
assert elapsed < limit  # Make sure the script is fast.
